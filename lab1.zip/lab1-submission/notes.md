https://github.com/cghuisunshine/JSFrameworkLab1

Following the instructions of Lab1, I successfully setup a simple web server using Bun and Hono:

    Learned how to set up a simple backend server using Bun with the Hono framework.

    Practiced running the server locally and tested different routes to confirm responses.

    Gained experience with initializing a new Git repository and tracking project files.

    Understood the workflow of making small code changes, committing them, and verifying functionality.

    Noticed how Bun provides fast startup and simple tooling compared to Node.js.
